
import java.util.ArrayList;
import java.util.List;

import com.zeroc.Ice.Communicator;
import com.zeroc.Ice.Current;
import com.zeroc.Ice.ObjectAdapter;
import com.zeroc.Ice.Util;

import ControladorMaquinaCafe.ControladorMQ;
import servicios.ServicioAbastecimiento;
import servicios.ServicioComMQCafePrx;
import servicios.ServicioUpdateReceta;
import servicios.ServicioProxyServerPrx;

public class CoffeeMach {

  public static class ServicioUpdateRecetaI implements ServicioUpdateReceta {
    private ControladorMQ service;

    public ServicioUpdateRecetaI(ControladorMQ service) {
      this.service = service;
    }

    @Override
    public void update(Current current) {
      System.out.println("------------------ACTUALIZADO-------------------------------");

      service.cargarRecetaMaquinas();

    }

  }

  public static void main(String[] args) {
    List<String> extPar = new ArrayList<>();
    try (Communicator communicator = Util.initialize(args, "coffeMach.cfg", extPar)) {

      ServicioComMQCafePrx comMQcafe = ServicioComMQCafePrx.checkedCast(
          communicator.propertyToProxy("MqCafe")).ice_twoway();
      ServicioProxyServerPrx proxySer = ServicioProxyServerPrx.checkedCast(
          communicator.propertyToProxy("ProxyServer")).ice_twoway();

      Thread destroyHook = new Thread(() -> communicator.destroy());
      Runtime.getRuntime().addShutdownHook(destroyHook);

      com.zeroc.IceStorm.TopicManagerPrx manager = com.zeroc.IceStorm.TopicManagerPrx.checkedCast(
          communicator.propertyToProxy("TopicManager.Proxy"));

      com.zeroc.IceStorm.TopicPrx topic = null;

      String topicName = "numero1";
      String retryCount = null;

      try {
        topic = manager.retrieve(topicName);
      } catch (com.zeroc.IceStorm.NoSuchTopic e) {
        try {
          topic = manager.create(topicName);
        } catch (com.zeroc.IceStorm.TopicExists ex) {
          System.err.println("temporary failure, try again.");

        }
      }

      String id = null;
      com.zeroc.Ice.Identity subId = new com.zeroc.Ice.Identity(id, "");

      subId.name = java.util.UUID.randomUUID().toString();

      ObjectAdapter adapter = communicator.createObjectAdapter("CoffeMach");

      ControladorMQ service = new ControladorMQ();
      service.setServicioComMQCafe(comMQcafe);
      service.setServicioMQProxy(proxySer);
      service.run();
      service.cargarRecetaMaquinas();
      adapter.add((ServicioAbastecimiento) service, Util.stringToIdentity("abastecer"));

      com.zeroc.Ice.ObjectPrx subscriber = adapter.add(new ServicioUpdateRecetaI(service), subId);

      adapter.activate();

      java.util.Map<String, String> hashmap = new java.util.HashMap<>();

      hashmap.put("retryCount", retryCount);

      try {
        topic.subscribeAndGetPublisher(hashmap, subscriber);
      } catch (Exception e) {
        e.printStackTrace();
      }

      communicator.waitForShutdown();
    }
  }
}
