
import java.util.ArrayList;
import java.util.List;
import com.zeroc.Ice.*;
import comunicacion.*;
import servicios.*;
import ServerControl.*;

public class ServidorCentral {

    public static void main(String[] args) {
        List<String> params = new ArrayList<>();
        try (Communicator communicator = Util.initialize(args, "server.cfg", params)) {

            ObjectAdapter adapter = communicator.createObjectAdapter("Server");

            com.zeroc.IceStorm.TopicManagerPrx manager = com.zeroc.IceStorm.TopicManagerPrx.checkedCast(
                    communicator.propertyToProxy("TopicManager.Proxy"));
            if (manager == null) {
                System.err.println("invalid proxy");

            }

            String topicName = "numero1";

            com.zeroc.IceStorm.TopicPrx topic = null;
            try {
                topic = manager.retrieve(topicName);
            } catch (com.zeroc.IceStorm.NoSuchTopic e) {
                try {
                    topic = manager.create(topicName);
                } catch (com.zeroc.IceStorm.TopicExists ex) {
                    System.err.println("temporary failure, try again.");

                }

            }

            com.zeroc.Ice.ObjectPrx publisher = topic.getPublisher();

			
			ServicioUpdateRecetaPrx servicio = ServicioUpdateRecetaPrx
                    .uncheckedCast(publisher);
					
            ServerControl control = new ServerControl(communicator, servicio);

            ServicioComLogistica log = new ControlComLogistica(control);
            ServicioComMQCafe comMQ = new ControlComMQCafe(control);
            ServicioProxyServer pro = new ControlProxyServer(control);
            ServicioClienteRecServidor recetas = new ControlClienteRecServidor(control);
            adapter.add(comMQ, Util.stringToIdentity("MQCafe"));
            adapter.add(log, Util.stringToIdentity("logistica"));
            adapter.add(pro, Util.stringToIdentity("proxy"));
            adapter.add(recetas, Util.stringToIdentity("recetas"));

            adapter.activate();
            communicator.waitForShutdown();

        }
    }
}
