package ServerControl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.zeroc.Ice.Communicator;

import modelo.*;
import servicios.ServicioUpdateRecetaPrx;

public class ServerControl {

	ArrayList<String> listaAsociada = new ArrayList<String>();
	private Communicator comunicator;

	private ServicioUpdateRecetaPrx updater;

	public ServerControl(Communicator com, ServicioUpdateRecetaPrx updater) {
		this.comunicator = com;
		this.updater = updater;

	}

	public boolean asignarOperador(int idMaquina, int idOperador) {
		if (idMaquina == 0 || idOperador == 0) {
			return false;
		} else {
			ConexionBD cbd = new ConexionBD(comunicator);
			cbd.conectarBaseDatos();
			ManejadorDatos md = new ManejadorDatos();
			md.setConexion(cbd.getConnection());
			md.asignarOperador(idOperador, idMaquina);
			cbd.cerrarConexion();
			return true;
		}
	}

	public List<String> listaAsignaciones(int codigooperador) {
		List<String> lista = new ArrayList<String>();

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		List<AsignacionMaquina> asmL = md.listaAsignaciones(codigooperador);

		for (AsignacionMaquina asm : asmL) {
			int idMaq = asm.getMaquina().peticioncodigo();
			String ubicacion = asm.getMaquina().getUbicacion();

			String dato = "" + idMaq + "-" + ubicacion;
			lista.add(dato);
		}
		cbd.cerrarConexion();
		return lista;
	}

	public List<String> listaAsignacionesMDanada(int codigoOperador) {
		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		List<String> listaAsign = md
				.listaAsignacionMaquinasDanadas(codigoOperador);
		cbd.cerrarConexion();
		return listaAsign;
	}

	public String darCorreoOperador(int codigoOperador) {
		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());
		String correo = md.darCorreoOperador(codigoOperador);
		cbd.cerrarConexion();
		return correo;
	}

	public boolean existeOperador(int codigoOperador, String contrasena) {

		if (codigoOperador != 0 && contrasena != null) {
			ConexionBD cbd = new ConexionBD(comunicator);
			cbd.conectarBaseDatos();
			ManejadorDatos md = new ManejadorDatos();
			md.setConexion(cbd.getConnection());
			boolean resultado = md.existeOperador(codigoOperador, contrasena);
			cbd.cerrarConexion();
			return resultado;
		}
		return false;

	}

	public String alarmaMaquina(int idAlarma, int idMaquina, Date fechainicial) {
		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		String alarma = md.darNombreAlarma(idAlarma);
		String operador = md.darOperador(idMaquina);

		if (alarma != null && operador != null) {
			AlarmaMaquina aM = new AlarmaMaquina(idAlarma, idMaquina,
					fechainicial);
			md.registrarAlarma(aM);
			cbd.cerrarConexion();
			return "Fallo de máquina: " + alarma + " - Atención por:"
					+ operador;
		}
		cbd.cerrarConexion();
		return null;
	}

	public void desactivarAlarma(int idAlarma, int idMaquina, Date fechaFinal) {
		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());
		md.desactivarAlarma(idMaquina, idAlarma, fechaFinal);
		cbd.cerrarConexion();
	}

	public void reporteVentas(int idMaquina, Date fechaInicial,
			Date fechaFinal, String[] detalle) {
		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		VentasMaquina vM = new VentasMaquina();
		vM.setFechaInicial(fechaInicial);
		vM.setFechaFinal(fechaFinal);
		vM.setIdMaquina(idMaquina);

		List<VentasReceta> vR = new ArrayList<VentasReceta>();

		for (String dato : detalle) {

			String[] div = dato.split("#");
			VentasReceta vRTemp = new VentasReceta();
			vRTemp.setIdReceta(Integer.parseInt(div[0]));

			vRTemp.setValorreceta(Integer.parseInt(div[1]));

			vR.add(vRTemp);
		}

		vM.setDetalle(vR);
		vM.setValor(0);

		md.registrarReporteVentas(vM);
		cbd.cerrarConexion();
	}

	public String[] update() {

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		listaAsociada = md.consultaRecetasCompleta();

		cbd.cerrarConexion();

		if (!listaAsociada.equals(null)) {

			String[] retorno = new String[listaAsociada.size()];

			for (int i = 0; i < listaAsociada.size(); i++) {

				retorno[i] = listaAsociada.get(i);
			}

			return retorno;
		}

		return null;

	}

	public String[] consultarRecetas() {

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		String[] ret = md.consultarRecetas();

		cbd.cerrarConexion();

		return ret;
	}

	public String[] consultarIngredientes() {

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		String[] ret = md.consultarIngredientes();

		cbd.cerrarConexion();

		return ret;

	}

	public String registrarIngrediente(String nombre) {

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		String ret = md.registrarIngrediente(nombre);

		cbd.cerrarConexion();

		return ret;

	}

	public String registrarReceta(String nombre, int precio) {

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		String ret = md.registrarReceta(nombre, precio);

		cbd.cerrarConexion();
		updater.update();
		return ret;

	}

	public void borrarReceta(int cod) {

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		md.borrarReceta(cod);

		cbd.cerrarConexion();
		updater.update();
	}

	public void registrarRecetaIngrediente(int idReceta, int idIngrediente,
			int valor) {

		ConexionBD cbd = new ConexionBD(comunicator);
		cbd.conectarBaseDatos();
		ManejadorDatos md = new ManejadorDatos();
		md.setConexion(cbd.getConnection());

		md.registrarRecetaIngrediente(idReceta, idIngrediente, valor);

		cbd.cerrarConexion();

	}
}
