package servicios;

import org.osoa.sca.annotations.Service;

@Service
public interface ServicioProxyServer {

	
	public String[] update();
}
