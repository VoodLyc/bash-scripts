package servicios;

import org.osoa.sca.annotations.Service;


@Service
public interface ServicioProxyCoffeMachine {
	
	
   public String[] notificar();

}
