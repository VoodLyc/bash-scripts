package control;

import java.util.Observer;

public abstract class Sujeto {
	
	public void attach(Observer o) {
		
	}
	
	public void detach(Observer o){
		
	}
	


}
