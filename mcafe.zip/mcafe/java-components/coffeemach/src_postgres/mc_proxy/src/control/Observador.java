package control;

public interface Observador {

	//public String[]update();
}
