create user P09713_1_2 identified by CweDiY14;
grant all priviliges to P09713_1_2;
